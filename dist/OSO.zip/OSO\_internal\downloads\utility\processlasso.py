from pathlib import Path
async def getURL():
    return "https://dl.bitsum.com/files/processlassosetup64.exe",(Path.home() / "Downloads" / "processlassosetup64.exe")