from pathlib import Path
from os import getcwd
async def getURL():
    return "https://github.com/HiGuys25/Interrupt-Affinity-Policy-Tool/releases/download/9/Interrupt.Affinity.Policy.Tool.exe",(getcwd()[:2] + r"\Oslivion\OSO\quickaccess\intPolicy_x64.exe")
#note: i have checked the hash and this is the same as intPolicy_x64.exe, you are safe :)