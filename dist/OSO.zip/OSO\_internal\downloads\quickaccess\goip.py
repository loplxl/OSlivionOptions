from pathlib import Path
from os import getcwd
async def getURL(ssl_ctx):
    return "https://github.com/spddl/GoInterruptPolicy/releases/latest/download/GoInterruptPolicy.exe",(getcwd()[:2] + r"\Oslivion\OSO\quickaccess\GoInterruptPolicy.exe")