from pathlib import Path
async def getURL():
    return "https://app.prntscr.com/build/setup-lightshot.exe",(Path.home() / "Downloads" / "setup-lightshot.exe")